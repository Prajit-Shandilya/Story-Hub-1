import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';

export default class Readscreen extends React.Component{
  render(){
  return (
    <View>
      <Text>
        Here you are.
      </Text>
     
    </View>
  );
}
}