import * as React from 'react';
import {
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Alert
} from 'react-native';
import Constants from 'expo-constants';
import { Header } from 'react-native-elements';
import { SafeAreaProvider } from 'react-native-safe-area-context';

export default class Writescreen extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      title: '',
      author: '',
      story: '',
    };
  }

  render() {
    return (
      <SafeAreaProvider>
      <View>
        <Header
        backgroundColor={'pink'}
          centerComponent={{ text: 'Story Hub' }}
        />
        <TextInput
          style={styles.inputBox}
          onChangeText={(text) => {
            this.setState({ title: text });
          }}
          value={this.state.title}
          placeholder="Story Title"
        />
        <TextInput
          style={styles.inputBox}
          onChangeText={(text) => {
            this.setState({ author: text });
          }}
          value={this.state.author}
          placeholder="Author"
        />
       
        <TextInput
          style={styles.storybox}
          onChangeText={(text) => {
            this.setState({ story: text });
          }}
          value={this.state.story}
          placeholder="Write your story"
          multiline={true}
        />
         <TouchableOpacity style={styles.touchO} onPress={()=>{Alert.alert('Hello I am AN AlertBox')}}>
          <Text>Submit</Text>
        </TouchableOpacity>
        
      </View>
      </SafeAreaProvider>
    );
  }
}

const styles = StyleSheet.create({
  inputBox: {
    height: 40,
      borderWidth: 2,
      marginTop: 1,
      margin: 10,
      color:'black',
      padding: 6,
  },
  storybox:{
     height: 250,
      borderWidth: 2,
      margin: 10, 
      padding: 6,
      marginTop:0,
  },
  touchO: {
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderRadius: 15,
    margin: 10,
   marginStart:50,
    width: 200,
    height: 30,
    backgroundColor:'pink',
    marginTop:0,
  },
});
